"""
Create fgmax_grid.txt input files 
"""


from clawpack.geoclaw import fgmax_tools
import datetime

def make_fgmax_grid():
    fg = fgmax_tools.FGmaxGrid()
    fg.point_style = 2       # will specify a 2d grid of points
    fg.x1 = -98       # west longitude 
    fg.x2 = -96.0       # east longitude
    fg.y1 = 27.0      # south latitude
    fg.y2 = 29.0     # north latitude
    fg.dx = 0.005 
    # Start and end times for observation
    landfall = datetime.datetime(2017, 8, 26, 3) - datetime.datetime(2017, 1, 1, 0)
    days2seconds = lambda days: days * 60.0**2 * 24.0
    fg.tstart_max = days2seconds(landfall.days - 0.5) + landfall.seconds  
    fg.tend_max = days2seconds(landfall.days + 0.25) + landfall.seconds

    fg.dt_check = 600.        # target time (sec) increment between updating 
                              # max values
    fg.min_level_check = 3    # which levels to monitor max on
    fg.arrival_tol = 1.e-1    # tolerance for flagging arrival

    fg.input_file_name = 'fgmax_grid.txt'
    fg.write_input_data()



if __name__ == "__main__":
    make_fgmax_grid()


