#!/usr/bin/env python

"""Simple implementation of a file fetcher"""

from __future__ import absolute_import
import sys
import os
from clawpack.clawutil import data

def get_bathy_data():
    # Default URLs
    base_url = "http://www.columbia.edu/~ktm2132/bathy/"

    urls = [os.path.join(base_url, 'gulf_caribbean.tt3.tar.bz2')]

    # # East of default domain gulf_caribbean.tt3 
    # minlat = 12
    # maxlat = 32
    # minlon = -71
    # maxlon = -65
    # # ERDDAP Data Access Form call
    # ETOPO_url = 'http://coastwatch.pfeg.noaa.gov/erddap/griddap/etopo180.esriAscii?altitude' + \
                        # '[('+str(minlat)+'):1:('+str(maxlat)+')][('+str(minlon)+'):1:('+str(maxlon)+')]'
    # urls.append(ETOPO_url)

    # Expansion of default domain gulf_caribbean.tt3 
    minlat = 15
    maxlat = 35
    minlon = -95
    maxlon = -65
    # ERDDAP Data Access Form call
    ETOPO_url = 'http://coastwatch.pfeg.noaa.gov/erddap/griddap/etopo180.esriAscii?altitude' + \
                        '[('+str(minlat)+'):1:('+str(maxlat)+')][('+str(minlon)+'):1:('+str(maxlon)+')]'
    urls.append(ETOPO_url)

    # Southwest Florida and Keys
    minlat = 24.5
    maxlat = 26.0
    minlon = -82.5
    maxlon = -80
    # ERDDAP Data Access Form call
    SRTM15_SWFlorida_url = 'http://coastwatch.pfeg.noaa.gov/erddap/griddap/srtm15plus.esriAscii?z[(' \
                            +str(minlat)+'):1:('+str(maxlat)+')][('+str(minlon)+'):1:('+str(maxlon)+')]'
    urls.append(SRTM15_SWFlorida_url)


    for url in urls:
        data.get_remote_file(url)

    # Get storm data too
    storm_filename = "irma.storm"
    if not os.path.isfile(storm_filename):
        if sys.version_info[0] < 3: # Python 2
            import urllib
            urllib.urlretrieve("ftp://ftp.nhc.noaa.gov/atcf/btk/bal112017.dat", storm_filename)
        else: # Python 3
            import urllib.request
            urllib.request.urlretrieve("ftp://ftp.nhc.noaa.gov/atcf/btk/bal112017.dat", storm_filename)
        print("Downloaded storm file ",storm_filename)

if __name__ == "__main__":
    get_bathy_data()
