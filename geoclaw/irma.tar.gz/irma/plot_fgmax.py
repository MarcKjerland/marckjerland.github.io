"""
Plot fgmax output from GeoClaw run.

"""

import matplotlib.pyplot as plt
import numpy as np
import os
from clawpack.geoclaw import fgmax_tools, geoplot

def plot_fgmax_grid():

    fg = fgmax_tools.FGmaxGrid()
    fg.read_input_data('fgmax_grid.txt')
    fg.read_output()

    clines_zeta = [0.1] + list(np.linspace(0.5,3.0,6))
    clines_zeta = list(np.linspace(0.1,3.0,10))
    # clines_zeta = [0.01] + list(np.linspace(0.05,0.3,6)) + [0.5,1.0,10.0]
    colors = geoplot.discrete_cmap_1(clines_zeta)

    # Generate plot
    plt.figure(1)
    plt.clf()
    surface = np.ma.masked_where(fg.h < 0.001, fg.h + fg.B)
    plt.contourf(fg.X,fg.Y,surface,clines_zeta,colors=colors)
    # plt.contourf(fg.X,fg.Y,surface,10)
    cb = plt.colorbar()
    plt.contour(fg.X,fg.Y,fg.B,[0.],colors='k')  # coastline
    cb.set_label('meters')
    plt.title('Southern Florida - Max surge height')

    # Save figure
    plotdir = '_plots'
    fname = os.path.join(plotdir, "max_height.png")
    plt.savefig(fname)
    print("Created ",fname)




if __name__=="__main__":
    plot_fgmax_grid()
