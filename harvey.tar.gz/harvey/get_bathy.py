#!/usr/bin/env python

"""Simple implementation of a file fetcher"""

from __future__ import absolute_import
import sys
import os
from clawpack.clawutil import data

def get_bathy_data():
    # Default URLs
    base_url = "http://www.columbia.edu/~ktm2132/bathy/"

    # Override base_url
    if len(sys.argv) > 1:
        base_url = sys.argv[1]

    urls = [os.path.join(base_url, 'gulf_caribbean.tt3.tar.bz2')]

    # Define the domain of interest
    minlat = 27.0
    maxlat = 29.0
    minlon = -98
    maxlon = -96.0
    # ERDDAP Data Access Form call
    SRTM15_Matagorda_url = 'http://coastwatch.pfeg.noaa.gov/erddap/griddap/srtm15plus.esriAscii?z[(' \
                            +str(minlat)+'):1:('+str(maxlat)+')][('+str(minlon)+'):1:('+str(maxlon)+')]'
    urls.append(SRTM15_Matagorda_url)

    for url in urls:
        data.get_remote_file(url)

    # Get storm data too
    storm_filename = "harvey.storm"
    if not os.path.isfile(storm_filename):
        if sys.version_info[0] < 3: # Python 2
            import urllib
            urllib.urlretrieve("ftp://ftp.nhc.noaa.gov/atcf/btk/bal092017.dat", storm_filename)
        else: # Python 3
            import urllib.request
            urllib.request.urlretrieve("ftp://ftp.nhc.noaa.gov/atcf/btk/bal092017.dat", storm_filename)
        print("Downloaded storm file ",storm_filename)

if __name__ == "__main__":
    get_bathy_data()
